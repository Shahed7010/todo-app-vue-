<template>
    <div class="flex-center" style="margin-top: 200px">
        <h1>Welcome to the Todo-List!</h1>
    </div>
</template>

<script>
    export default {
        name: "LandingPage"
    }
</script>

<style scoped>

</style>
<template>
    <div class="flex-center">
        this is about page
    </div>
</template>

<script>
    export default {
        name: "About"
    }
</script>

<style scoped>

</style>
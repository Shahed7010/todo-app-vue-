<template>
    <div class="flex-center">
        the given parameter is : {{$route.params.id}}
    </div>
</template>

<script>
    export default {
        name: "TestComp"
    }
</script>

<style scoped>

</style>